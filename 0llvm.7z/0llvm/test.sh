#环境部署
cd ./Build
cmake ../Transforms
make
cd ../Test
clang -S -emit-llvm TestProgram.cpp -o IR/TestProgram.ll

#普通编译
#opt -load ../Build/LLVMObfuscator.so -hlw -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_hlw.ll
#clang IR/TestProgram_hlw.ll -o Bin/TestProgram_hlw

#分块编译
#opt -load ../Build/LLVMObfuscator.so -split -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_split.ll 
#clang IR/TestProgram_split.ll -o Bin/TestProgram_split
#flag{s1mpl3_11vm_d3m0}

#fla控制流平坦化编译
#opt -lowerswitch -S IR/TestProgram.ll -o IR/TestProgram_lowerswitch.ll
#opt -load ../Build/LLVMObfuscator.so -fla -S -enable-new-pm=0 IR/TestProgram_lowerswitch.ll -o IR/TestProgram_fla.ll
#clang IR/TestProgram_fla.ll -o Bin/TestProgram_fla
#./Bin/TestProgram_fla flag{s1mpl3_11vm_d3m0}

#虚假控制流编译
# opt -load ../Build/LLVMObfuscator.so -bcf -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_bcf.ll
# opt -load ../Build/LLVMObfuscator.so -bcf -bcf_loop 2 -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_bcf.ll
# #混淆次数
# clang  IR/TestProgram_bcf.ll -o Bin/TestProgram_bcf
# ./Bin/TestProgram_bcf flag{s1mpl3_11vm_d3m0}

#指令替代编译
# opt -load ../Build/LLVMObfuscator.so -sub -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_sub.ll
# opt -load ../Build/LLVMObfuscator.so -sub -sub_loop 2 -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_sub.ll
# clang  IR/TestProgram_sub.ll -o Bin/TestProgram_sub
# ./Bin/TestProgram_sub flag{s1mpl3_11vm_d3m0}

# 随机控制流编译
# opt -load ../Build/LLVMObfuscator.so -rcf -rcf_loop 1 -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_rcf.ll
# llc -filetype=obj -mattr=+rdrnd  IR/TestProgram_rcf.ll -o Bin/TestProgram_rcf.o # 不加这行，编译器后端会找不到rdrnd 所以要手动静态编译成.o文件
# clang Bin/TestProgram_rcf.o -o Bin/TestProgram_rcf -no-pie
# ./Bin/TestProgram_rcf flag{s1mpl3_11vm_d3m0}

# echo "------------------------------------Constant Substitution  --------------------------------------------"
opt -load ../Build/LLVMObfuscator.so -csub -csub_loop 3 -S -enable-new-pm=0 IR/TestProgram.ll -o IR/TestProgram_csub.ll 
clang IR/TestProgram_csub.ll -o Bin/TestProgram_csub
./Bin/TestProgram_csub flag{s1mpl3_11vm_d3m0}